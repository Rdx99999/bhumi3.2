import { Helmet } from 'react-helmet';
import StructuredData from './StructuredData';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  structuredData?: {
    type: 'organization' | 'localBusiness' | 'service' | 'trainingCourse';
    data: Record<string, any>;
  };
}

export default function SEO({
  title = 'Bhumi Consultancy Services | Professional Business Solutions',
  description = 'Bhumi Consultancy offers professional business consulting, training programs, and certification services to help businesses achieve their full potential.',
  keywords = 'business consulting, training programs, certification, audit services, bhumi consultancy',
  canonicalUrl = import.meta.env.VITE_DOMAIN || 'https://bhumiconsultancy.in',
  ogImage = '/images/og-image.jpg',
  structuredData
}: SEOProps) {
  
  // Base title for the company
  const baseTitle = 'Bhumi Consultancy Services';
  
  // Format the title - if it doesn't already contain the base title, append it
  const formattedTitle = title.includes(baseTitle) 
    ? title 
    : `${title} | ${baseTitle}`;
  
  return (
    <>
      <Helmet>
        {/* Basic Meta Tags */}
        <title>{formattedTitle}</title>
        <meta name="description" content={description} />
        <meta name="keywords" content={keywords} />
        
        {/* Canonical Link */}
        <link rel="canonical" href={canonicalUrl} />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:title" content={formattedTitle} />
        <meta property="og:description" content={description} />
        <meta property="og:image" content={ogImage} />
        
        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:url" content={canonicalUrl} />
        <meta name="twitter:title" content={formattedTitle} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={ogImage} />
      </Helmet>
      
      {/* Add JSON-LD structured data if provided */}
      {structuredData && (
        <StructuredData 
          type={structuredData.type} 
          data={structuredData.data} 
        />
      )}
    </>
  );
}