# Bhumi Consultancy Website

A full-stack application for a consultancy company offering business consulting services, audit preparation, and training programs with certificate verification functionality.

## Project Overview

Bhumi Consultancy website is built using modern web technologies:

- **Frontend**: React.js, Tailwind CSS, Shadcn/UI components
- **Backend**: Express server for development, Cloudflare Workers for production
- **Database**: In-memory storage for development, Cloudflare D1 (SQLite) for production

## Features

### 1. Services Showcase
- Display consultancy services with descriptions and features
- Highlight business consulting and audit preparation services

### 2. Training Programs
- List all training programs with categories, duration, and pricing
- Filter training programs by category and duration
- Detailed program descriptions and enrollment information

### 3. Certificate Verification System
- Verify certificate authenticity by certificate ID and participant name
- Display certificate details including issue date and status
- Certificate download functionality

### 4. Participant Status Check
- Check training status using participant ID or email
- View enrolled programs, completion status, and certificates
- Track training progress

### 5. Contact Form
- Submit inquiries through a validated contact form
- Store contact messages in the database

### 6. SEO Optimization
- Dynamic sitemap generation based on current content
- Proper meta tags and structured data for search engines
- Optimized robots.txt file

## Project Structure

```
├── client/                  # Frontend React application
│   ├── src/
│   │   ├── components/      # UI components
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions and API clients
│   │   ├── pages/           # Page components
│   │   └── ...
├── server/                  # Express server for development
│   ├── index.ts             # Server entry point
│   ├── routes.ts            # API routes
│   ├── storage.ts           # In-memory storage implementation
│   └── vite.ts              # Vite configuration for the server
├── shared/                  # Shared code between client and server
│   ├── schema.ts            # Database schema and type definitions
│   └── cloudflare-api.ts    # Cloudflare Worker API interface
├── cloudflare-worker/       # Cloudflare Worker implementation
│   ├── worker.js            # Worker code
│   ├── wrangler.toml        # Cloudflare Worker configuration
│   ├── schema.sql           # D1 database schema
│   └── sample-data.sql      # Sample data for the D1 database
└── ...
```

## Deployment

### Development Environment
The project runs in a development environment using:
- Vite for frontend
- Express for backend
- In-memory storage for data

To start the development server:
```
npm run dev
```

### Production Environment
For production deployment:
1. Deploy the React frontend to a static hosting provider
2. Deploy the Cloudflare Worker using Wrangler
3. Set up a Cloudflare D1 database and apply the schema

## Database Schema

The application uses the following database schema:

1. **Users** - Administrative users
2. **Services** - Consultancy services information
3. **Training Programs** - Available training programs
4. **Participants** - Enrolled participants information
5. **Certificates** - Issued certificates
6. **Contacts** - Contact form submissions

## API Endpoints

The API provides the following endpoints:

### GET Endpoints
- GET `/api/services` - Get all services
- GET `/api/training-programs` - Get all training programs
- GET `/api/training-programs/:id` - Get a specific training program
- GET `/api/certificate/:id/download` - Download a certificate
- GET `/sitemap.xml` - Dynamic sitemap for SEO (generated from current content)

### POST Endpoints
- POST `/api/verify-certificate` - Verify a certificate
- POST `/api/check-status` - Check participant status
- POST `/api/contact` - Submit a contact form

For detailed API documentation, refer to the [Cloudflare Worker README](./cloudflare-worker/README.md).

## Certificate Verification

To test the certificate verification system, use the following sample data:
- Certificate ID: "BHM23051501"
- Participant Name: "John Doe"

## License

This project is licensed under the MIT License.